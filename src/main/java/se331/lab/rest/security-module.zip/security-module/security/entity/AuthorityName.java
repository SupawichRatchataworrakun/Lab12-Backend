package se331.lab.rest.security.entity;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}